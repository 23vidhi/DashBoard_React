import React from 'react'

function Card() {
  return (
    <div className="bg-white shadow-md rounded-lg p-6 flex w-[100%]  mt-5 h-[65.8%] ">

    </div>
    
  )
}

export default Card