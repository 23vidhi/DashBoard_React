import React from 'react'
import Body_div5_1 from './Body_div5_1'
import Body_div5_2 from './Body_div5_2'

function Body_div5() {
  return (
    <div className="flex gap-6 mt-6">
        <Body_div5_1/>
        <Body_div5_2/>

      
    </div>
  )
}

export default Body_div5
