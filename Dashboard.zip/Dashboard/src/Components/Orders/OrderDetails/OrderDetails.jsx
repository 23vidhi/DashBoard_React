import React from 'react'

function OrderDetails() {
  return (
    <div>
      
    </div>
  )
}

export default OrderDetails
