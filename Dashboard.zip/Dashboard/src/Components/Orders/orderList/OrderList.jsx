import React from 'react'
import Card from './Card'


function OrderList() {
  return (
    <div>
      <Card/>
    </div>
  )
}

export default OrderList
