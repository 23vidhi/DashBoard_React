import React from "react";
import RouteLayout from "../Components/RouteLayout";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Body from "../Components/Body";
import "../index.css";
import OrderList from "../Components/Orders/orderList/OrderList";

const router = createBrowserRouter([
  {
    path: "/",
    element: <RouteLayout />,
    children: [
      {
        path: "",
        element: <Body />,
      },
      {
        path: "/OrderList",
        element: <OrderList />, 
      },
    ],
  },
]);

const AppRoutes = () => {
  return <RouterProvider router={router} />;
};

export default AppRoutes;
